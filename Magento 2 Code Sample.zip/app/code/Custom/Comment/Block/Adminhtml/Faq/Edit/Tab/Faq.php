<?php
namespace Custom\Comment\Block\Adminhtml\Faq\Edit\Tab;

use Custom\Comment\Model\Status;

/**
 * Comment Edit tab.
 * @category Custom
 * @package  Custom_Comment
 * @module   Comment
 * @author   Ripal Patel.
 */

class Faq extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    protected $_objectFactory;

    protected $_faq;
    
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Framework\DataObjectFactory $objectFactory,
        \Custom\Comment\Model\Faq $faq,
        array $data = []
    ) {
        $this->_objectFactory = $objectFactory;
        $this->_faq = $faq;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    protected function _prepareLayout()
    {
        $this->getLayout()->getBlock('page.title')->setPageTitle($this->getPageTitle());

        \Magento\Framework\Data\Form::setFieldsetElementRenderer(
            $this->getLayout()->createBlock(
                'Custom\Comment\Block\Adminhtml\Form\Renderer\Fieldset\Element',
                $this->getNameInLayout().'_fieldset_element'
            )
        );

        return $this;
    }

    protected function _prepareForm()
    {
		$faqAttributes = $this->_faq->getStoreAttributes();
        $faqAttributesInStores = ['store_id' => ''];

        foreach ($faqAttributes as $faqAttribute) {
            $faqAttributesInStores[$faqAttribute.'_in_store'] = '';
        }

        $dataObj = $this->_objectFactory->create(
            ['data' => $faqAttributesInStores]
        );
        $model = $this->_coreRegistry->registry('faq');

        $dataObj->addData($model->getData());

        $storeViewId = $this->getRequest()->getParam('store');
		
        $form = $this->_formFactory->create();
		
        $form->setHtmlIdPrefix($this->_faq->getFormFieldHtmlIdPrefix());
		
        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Comment Information')]);

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', ['name' => 'id']);
        }

        $elements = [];
        $elements['customer_id'] = $fieldset->addField(
            'customer_id',
            'text',
            [
                'name' => 'customer_id',
                'label' => __('Customer Id'),
                'title' => __('Customer Id'),
                'required' => true,
            ]
        );
		
		$elements['product_id'] = $fieldset->addField(
            'product_id',
            'text',
            [
                'name' => 'product_id',
                'label' => __('Product Id'),
                'title' => __('Product Id'),
                'required' => true,
            ]
        );
		
		$elements['comment'] = $fieldset->addField(
            'comment',
            'text',
            [
                'name' => 'comment',
                'label' => __('comment'),
                'title' => __('comment'),
                'required' => true,
            ]
        );

        $elements['status'] = $fieldset->addField(
            'status',
            'select',
            [
                'label' => __('Status'),
                'title' => __('Status'),
                'name' => 'status',
                'options' => Status::getAvailableStatuses(),
            ]
        );

        $form->addValues($dataObj->getData());
        $this->setForm($form);

        return parent::_prepareForm();
    }

    public function getFaq()
    {
        return $this->_coreRegistry->registry('faq');
    }

    public function getPageTitle()
    {
        return $this->getFaq()->getId()? __("EDIT Comment '%1'", $this->escapeHtml($this->getFaq()->getName())) : __('NEW Comment');
    }

    public function getTabLabel()
    {
        return __('Comment Information');
    }

    public function getTabTitle()
    {
        return __('Comment Information');
    }

    public function canShowTab()
    {
        return true;
    }

    public function isHidden()
    {
        return false;
    }
}
