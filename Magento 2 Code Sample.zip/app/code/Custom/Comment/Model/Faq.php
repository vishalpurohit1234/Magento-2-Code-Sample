<?php

namespace Custom\Comment\Model;

/**
 * Comment Model
 * @category Custom
 * @package  Custom_Comment
 * @module   Comment
 * @author   Ripal Patel.
 */

class Faq extends \Magento\Framework\Model\AbstractModel
{
    const Comment_TARGET_SELF = 0;
    const Comment_TARGET_PARENT = 1;
    const Comment_TARGET_BLANK = 2;
	
    protected $_storeViewId = null;

    protected $_faqFactory;

    protected $_formFieldHtmlIdPrefix = 'page_';
	
    protected $_storeManager;

    protected $_monolog;

    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Custom\Comment\Model\ResourceModel\Faq $resource,
        \Custom\Comment\Model\ResourceModel\Faq\Collection $resourceCollection,
        \Custom\Comment\Model\FaqFactory $faqFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Logger\Monolog $monolog
    ) {
        parent::__construct(
            $context,
            $registry,
            $resource,
            $resourceCollection
        );
        $this->_faqFactory = $faqFactory;
        $this->_storeManager = $storeManager;

        $this->_monolog = $monolog;

        if ($storeViewId = $this->_storeManager->getStore()->getId()) {
            $this->_storeViewId = $storeViewId;
        }
    }

    public function getFormFieldHtmlIdPrefix()
    {
        return $this->_formFieldHtmlIdPrefix;
    }
	
    public function getStoreAttributes()
    {
        return array(
            'name',
            'status',
        );
    }

    public function getStoreViewId()
    {
        return $this->_storeViewId;
    }

    public function setStoreViewId($storeViewId)
    {
        $this->_storeViewId = $storeViewId;

        return $this;
    }

    public function load($id, $field = null)
    {
        parent::load($id, $field);
        if ($this->getStoreViewId()) {
            $this->getStoreViewValue();
        }

        return $this;
    }

    public function getTargetValue()
    {
        switch ($this->getTarget()) {
            case self::Comment_TARGET_SELF:
                return '_self';
            case self::Comment_TARGET_PARENT:
                return '_parent';

            default:
                return '_blank';
        }
    }
}
