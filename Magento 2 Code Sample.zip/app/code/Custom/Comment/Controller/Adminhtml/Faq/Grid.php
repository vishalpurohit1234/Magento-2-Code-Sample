<?php

namespace Custom\Comment\Controller\Adminhtml\Faq;

/**
 * Grid action.
 * @category Custom
 * @package  Custom_Comment
 * @module   Comment
 * @author   Ripal Patel.
 */

class Grid extends \Custom\Comment\Controller\Adminhtml\Faq
{
    public function execute()
    {
        $resultLayout = $this->_resultLayoutFactory->create();
		
        return $resultLayout;
    }
}
