<?php
namespace Custom\Comment\Controller\Index;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Add extends \Magento\Framework\App\Action\Action
{
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    )
    {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }
 
    public function execute()
    {
		//echo "hello";die;
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$customerSession = $objectManager->create('Magento\Customer\Model\Session');
		//if($customerSession->isLoggedIn()) { //customer is loggedin or not
		$customerid = $customerSession->getCustomerId(); 
		//}
		$data = $this->getRequest()->getPostValue();
			if($data['commentbox']!='')
			{
				//echo "<pre>"; print_r($data); die;
				$comment = $data['commentbox'];
				$productid = $data['productid'];
				$createdat = date("Y-m-d");
				$model = $this->_objectManager->create('Custom\Comment\Model\Faq');
				$model->setComment($comment);
				$model->setProductId($productid);
				$model->setCreatedAt($createdat);
				$model->setCustomerId($customerid);
				$model->save();
			}
			/*$this->_redirect('comment/index');
			return;
			$this->_view->loadLayout();
			$this->_view->getLayout()->initMessages();
			$this->_view->renderLayout();*/
			$this->messageManager->addSuccess(__('Your comment is submitted successfully.'));
			$resultRedirect = $this->resultRedirectFactory->create();
			$resultRedirect->setRefererOrBaseUrl();
			return $resultRedirect;
			$this->_redirect($this->_redirect->getRefererUrl());
    }
}

