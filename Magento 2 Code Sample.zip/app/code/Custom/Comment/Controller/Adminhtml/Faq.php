<?php

namespace Custom\Comment\Controller\Adminhtml;

/**
 * Comment Abstract Action
 * @category Custom
 * @package  Custom_Comment
 * @module   Comment
 * @author   Ripal Patel.
 */

abstract class Faq extends \Custom\Comment\Controller\Adminhtml\AbstractAction
{
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Custom_Comment::comment_faq');
    }
}
