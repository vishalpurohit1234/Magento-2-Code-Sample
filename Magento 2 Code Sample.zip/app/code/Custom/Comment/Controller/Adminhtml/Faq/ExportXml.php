<?php
namespace Custom\Comment\Controller\Adminhtml\Faq;

use Magento\Framework\App\Filesystem\DirectoryList;

/**
 * ExportXML action.
 * @category Custom
 * @package  Custom_Comment
 * @module   Comment
 * @author   Ripal Patel.
 */

class ExportXml extends \Custom\Comment\Controller\Adminhtml\Faq
{
    public function execute()
    {
        $fileName = 'faq.xml';

        $resultPage = $this->_resultPageFactory->create();
        $content = $resultPage->getLayout()->createBlock('Custom\Comment\Block\Adminhtml\Faq\Grid')->getXml();

        return $this->_fileFactory->create($fileName, $content, DirectoryList::VAR_DIR);
    }
}
