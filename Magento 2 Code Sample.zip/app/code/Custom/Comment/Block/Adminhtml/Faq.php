<?php
namespace Custom\Comment\Block\Adminhtml;

/**
 * Comment grid container.
 * @category Custom
 * @package  Custom_Comment
 * @module   Comment
 * @author   Ripal Patel.
 */

class Faq extends \Magento\Backend\Block\Widget\Grid\Container
{
    protected function _construct()
    {
        $this->_controller = 'adminhtml_faq';
        $this->_blockGroup = 'Custom_Comment';
        $this->_headerText = __('Comment');
        $this->_addButtonLabel = __('Add New Comment');
        parent::_construct();
    }
}
