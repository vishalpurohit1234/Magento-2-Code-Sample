<?php
namespace Custom\Comment\Controller\Adminhtml\Faq;

/**
 * Edit Comment action.
 * @category Custom
 * @package  Custom_Comment
 * @module   Comment
 * @author   Ripal Patel.
 */

class Edit extends \Custom\Comment\Controller\Adminhtml\Faq
{
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        $storeViewId = $this->getRequest()->getParam('store');
        $model = $this->_faqFactory->create();
		//echo "<pre>"; print_r($model->getData()); die;
        if ($id) {
            $model->setStoreViewId($storeViewId)->load($id);
            if (!$model->getId()) {
                $this->messageManager->addError(__('This Comment no longer exists.'));
                $resultRedirect = $this->_resultRedirectFactory->create();

                return $resultRedirect->setPath('*/*/');
            }
        }

        $data = $this->_getSession()->getFormData(true);
        if (!empty($data)) {
            $model->setData($data);
        }

        $this->_coreRegistry->register('faq', $model);

        $resultPage = $this->_resultPageFactory->create();

        return $resultPage;
    }
}
