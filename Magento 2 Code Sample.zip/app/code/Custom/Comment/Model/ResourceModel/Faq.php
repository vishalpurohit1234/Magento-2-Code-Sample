<?php
namespace Custom\Comment\Model\ResourceModel;

/**
 * Comment Resource Model
 * @category Custom
 * @package  Custom_Comment
 * @module   Comment
 * @author   Ripal Patel.
 */

class Faq extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('custom_comment', 'id');
    }
}
