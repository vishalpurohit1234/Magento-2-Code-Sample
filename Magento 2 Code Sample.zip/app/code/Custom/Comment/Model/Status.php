<?php
namespace Custom\Comment\Model;

/**
 * Status
 * @category Custom
 * @package  Custom_Comment
 * @module   Comment
 * @author   Ripal Patel.
 */

class Status
{
    const STATUS_ENABLED = 1;
    const STATUS_DISABLED = 2;

    public static function getAvailableStatuses()
    {
        return [
            self::STATUS_ENABLED => __('Enabled')
            , self::STATUS_DISABLED => __('Disabled'),
        ];
    }
}
