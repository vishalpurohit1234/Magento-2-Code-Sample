<?php
namespace Custom\Comment\Block;

use Custom\Comment\Model\Status;

/**
 * Comment Block
 * @category Custom
 * @package  Custom_Comment
 * @module   Comment
 * @author   Custom Infosolutions Pvt. Ltd.
 */

class Faq extends \Magento\Framework\View\Element\Template
{
    protected $_template = 'Custom_Comment::index.phtml';
	protected $_coreRegistry;
	protected $_scopeConfig;
	protected $_storeManager;
	protected $_faqCollectionFactory;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Custom\Comment\Model\ResourceModel\Faq\CollectionFactory $faqCollectionFactory,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->_coreRegistry = $coreRegistry;
		$this->_faqCollectionFactory = $faqCollectionFactory;
        $this->_scopeConfig = $context->getScopeConfig();
        $this->_storeManager = $context->getStoreManager();
    }
	public function getCommentCollection() {
		//echo "test";die;
	   return $commentCollection = $this->_faqCollectionFactory->create()->addFieldToFilter('status',1);
	   
	   //return $commentCollection;
	}
	
}
