<?php
namespace Custom\Comment\Controller\Adminhtml\Faq;

/**
 * Delete Comment action
 * @category Custom
 * @package  Custom_Comment
 * @module   Comment
 * @author   Ripal Patel.
 */

class Delete extends \Custom\Comment\Controller\Adminhtml\Faq
{
    public function execute()
    {
        $Id = $this->getRequest()->getParam('id');
        try {
            $faq = $this->_faqFactory->create()->setId($Id);
            $faq->delete();
            $this->messageManager->addSuccess(
                __('Delete successfully !')
            );
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }

        $resultRedirect = $this->_resultRedirectFactory->create();

        return $resultRedirect->setPath('*/*/');
    }
}
