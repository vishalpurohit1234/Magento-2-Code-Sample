<?php
namespace Custom\Comment\Controller\Adminhtml\Faq;

/**
 * Index action.
 * @category Custom
 * @package  Custom_Comment
 * @module   Comment
 * @author   Ripal Patel.
 */

class Index extends \Custom\Comment\Controller\Adminhtml\Faq
{
    public function execute()
    {
        if ($this->getRequest()->getQuery('ajax')) {
            $resultForward = $this->_resultForwardFactory->create();
            $resultForward->forward('grid');

            return $resultForward;
        }

        $resultPage = $this->_resultPageFactory->create();

        $this->_addBreadcrumb(__('Comment'), __('Comment'));
        $this->_addBreadcrumb(__('Manage Comment'), __('Manage Comment'));

        return $resultPage;
    }
}
