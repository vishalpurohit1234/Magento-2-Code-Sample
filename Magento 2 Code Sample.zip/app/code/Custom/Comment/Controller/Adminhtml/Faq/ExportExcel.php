<?php
namespace Custom\Comment\Controller\Adminhtml\Faq;

use Magento\Framework\App\Filesystem\DirectoryList;

/**
 * ExportExcel action.
 * @category Custom
 * @package  Custom_Comment
 * @module   Comment
 * @author   Ripal Patel.
 */

class ExportExcel extends \Custom\Comment\Controller\Adminhtml\Faq
{
    public function execute()
    {
        $fileName = 'faq.xls';

        $resultPage = $this->_resultPageFactory->create();
        $content = $resultPage->getLayout()->createBlock('Custom\Comment\Block\Adminhtml\Faq\Grid')->getExcel();

        return $this->_fileFactory->create($fileName, $content, DirectoryList::VAR_DIR);
    }
}
