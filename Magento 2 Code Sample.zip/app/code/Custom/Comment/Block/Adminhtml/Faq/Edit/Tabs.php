<?php
namespace Custom\Comment\Block\Adminhtml\Faq\Edit;

/**
 * Comment Tabs.
 * @category Custom
 * @package  Custom_Comment
 * @module   Comment
 * @author   Ripal Patel.
 */

class Tabs extends \Magento\Backend\Block\Widget\Tabs
{
    protected function _construct()
    {
        parent::_construct();
        $this->setId('faq_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Comment Information'));
    }
}
